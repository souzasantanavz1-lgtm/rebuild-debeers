-- 1. Drop the dangerous user UPDATE policy that allows direct balance manipulation
DROP POLICY IF EXISTS "Users can update their own balance" ON public.user_balances;

-- 2. Create a secure RPC function for claiming daily check-in
-- This prevents users from directly modifying their balance
CREATE OR REPLACE FUNCTION public.claim_daily_checkin()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id UUID;
  v_today DATE;
  v_amount DECIMAL(10,2) := 0.50;
  v_new_balance DECIMAL(10,2);
  v_existing_checkin BOOLEAN;
BEGIN
  -- Get authenticated user
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  v_today := CURRENT_DATE;
  
  -- Check if already claimed today
  SELECT EXISTS (
    SELECT 1 FROM public.daily_checkins 
    WHERE user_id = v_user_id AND checkin_date = v_today
  ) INTO v_existing_checkin;
  
  IF v_existing_checkin THEN
    RETURN jsonb_build_object('success', false, 'error', 'already_claimed', 'message', 'Você já resgatou o prêmio de hoje');
  END IF;
  
  -- Ensure user has a balance record
  INSERT INTO public.user_balances (user_id, investment_balance, withdrawal_balance)
  VALUES (v_user_id, 0, 0)
  ON CONFLICT (user_id) DO NOTHING;
  
  -- Insert checkin record (marked as credited immediately)
  INSERT INTO public.daily_checkins (user_id, checkin_date, amount, is_credited, credited_at)
  VALUES (v_user_id, v_today, v_amount, true, now());
  
  -- Update balance (server-side only - users cannot do this directly anymore)
  UPDATE public.user_balances
  SET investment_balance = investment_balance + v_amount,
      updated_at = now()
  WHERE user_id = v_user_id
  RETURNING investment_balance INTO v_new_balance;
  
  RETURN jsonb_build_object(
    'success', true, 
    'new_balance', v_new_balance, 
    'amount', v_amount,
    'message', 'Prêmio resgatado com sucesso!'
  );
EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('success', false, 'error', 'already_claimed', 'message', 'Você já resgatou o prêmio de hoje');
  WHEN OTHERS THEN
    RETURN jsonb_build_object('success', false, 'error', 'server_error', 'message', 'Erro ao processar o resgate');
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.claim_daily_checkin() TO authenticated;