-- Create user_balances table to track investment balance
CREATE TABLE public.user_balances (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  investment_balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  withdrawal_balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create daily_checkins table to track check-in history
CREATE TABLE public.daily_checkins (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  checkin_date DATE NOT NULL,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0.50,
  credited_at TIMESTAMP WITH TIME ZONE,
  is_credited BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add unique constraint to prevent duplicate check-ins per day
ALTER TABLE public.daily_checkins 
ADD CONSTRAINT unique_user_checkin_per_day UNIQUE (user_id, checkin_date);

-- Enable RLS
ALTER TABLE public.user_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_checkins ENABLE ROW LEVEL SECURITY;

-- RLS policies for user_balances
CREATE POLICY "Users can view their own balance" 
ON public.user_balances FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own balance" 
ON public.user_balances FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own balance" 
ON public.user_balances FOR UPDATE 
USING (auth.uid() = user_id);

-- RLS policies for daily_checkins
CREATE POLICY "Users can view their own checkins" 
ON public.daily_checkins FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own checkins" 
ON public.daily_checkins FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Service role policy for the cron job to update checkins
CREATE POLICY "Service role can update checkins"
ON public.daily_checkins FOR UPDATE
USING (true);

CREATE POLICY "Service role can update balances"
ON public.user_balances FOR UPDATE
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_user_balances_updated_at
BEFORE UPDATE ON public.user_balances
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Function to credit pending check-ins (called by cron at 12:00)
CREATE OR REPLACE FUNCTION public.credit_pending_checkins()
RETURNS void AS $$
DECLARE
  checkin_record RECORD;
BEGIN
  -- Find all uncredited check-ins from yesterday or earlier
  FOR checkin_record IN 
    SELECT dc.id, dc.user_id, dc.amount
    FROM public.daily_checkins dc
    WHERE dc.is_credited = false
    AND dc.checkin_date < CURRENT_DATE
  LOOP
    -- Ensure user has a balance record
    INSERT INTO public.user_balances (user_id, investment_balance)
    VALUES (checkin_record.user_id, 0)
    ON CONFLICT (user_id) DO NOTHING;
    
    -- Credit the amount to investment_balance
    UPDATE public.user_balances
    SET investment_balance = investment_balance + checkin_record.amount,
        updated_at = now()
    WHERE user_id = checkin_record.user_id;
    
    -- Mark checkin as credited
    UPDATE public.daily_checkins
    SET is_credited = true,
        credited_at = now()
    WHERE id = checkin_record.id;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;