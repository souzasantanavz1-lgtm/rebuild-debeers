-- Remove overly permissive service role UPDATE policies
-- Service role bypasses RLS by default, so these policies are redundant
-- and create unnecessary security surface area if service role key is compromised

-- Drop the service role policies - they're not needed since:
-- 1. SECURITY DEFINER functions (like claim_daily_checkin and credit_pending_checkins) 
--    already execute with elevated privileges
-- 2. Service role bypasses RLS entirely regardless of policies
DROP POLICY IF EXISTS "Service role can update checkins" ON public.daily_checkins;
DROP POLICY IF EXISTS "Service role can update balances" ON public.user_balances;