import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  ArrowLeft, 
  MessageCircle, 
  Mail, 
  Phone, 
  HelpCircle, 
  FileQuestion,
  Clock,
  Diamond,
  Send,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import BottomNavigation from "@/components/BottomNavigation";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { supportTicketSchema, sanitizeText } from "@/lib/validations/support";

const Support = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [subject, setSubject] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ subject?: string; message?: string }>({});

  const handleSendMessage = () => {
    setErrors({});
    
    // Validate input using zod schema
    const result = supportTicketSchema.safeParse({ 
      subject: subject.trim(), 
      message: message.trim() 
    });
    
    if (!result.success) {
      const fieldErrors: { subject?: string; message?: string } = {};
      result.error.errors.forEach((err) => {
        if (err.path[0] === 'subject') {
          fieldErrors.subject = err.message;
        }
        if (err.path[0] === 'message') {
          fieldErrors.message = err.message;
        }
      });
      setErrors(fieldErrors);
      
      toast({
        title: "Dados inválidos",
        description: result.error.errors[0].message,
        variant: "destructive",
      });
      return;
    }

    // Sanitize inputs before processing
    const cleanSubject = sanitizeText(result.data.subject);
    const cleanMessage = sanitizeText(result.data.message);
    
    // For now, just show success toast (backend not implemented yet)
    // When backend is ready, this will call an edge function
    setIsSubmitting(true);
    
    // Simulate submission delay
    setTimeout(() => {
      toast({
        title: "Mensagem enviada!",
        description: "Nossa equipe responderá em até 24 horas úteis.",
      });
      setSubject("");
      setMessage("");
      setIsSubmitting(false);
    }, 500);
  };

  const handleWhatsApp = () => {
    toast({
      title: "WhatsApp",
      description: "Redirecionando para o atendimento...",
    });
    // In production, this would open WhatsApp
  };

  const handleEmail = () => {
    toast({
      title: "E-mail",
      description: "suporte@debeers.com.br",
    });
  };

  const faqItems = [
    {
      question: "Como faço um depósito?",
      answer: "Acesse o menu 'Depositar', escolha o valor desejado e siga as instruções de pagamento via PIX. O crédito é processado automaticamente após a confirmação do pagamento."
    },
    {
      question: "Quanto tempo demora para sacar?",
      answer: "Os saques são processados em até 24 horas úteis. O valor é transferido diretamente para a chave PIX cadastrada na sua conta."
    },
    {
      question: "Como funciona o rendimento dos planos?",
      answer: "Cada plano possui uma taxa de rendimento diário. Os lucros são creditados automaticamente todo dia às 00:00 e podem ser visualizados no extrato."
    },
    {
      question: "O que é o Check-in Diário?",
      answer: "O Check-in Diário é uma bonificação de R$ 0,50 que você recebe ao acessar a plataforma todos os dias. Basta clicar em 'Resgatar' na seção de Check-in."
    },
    {
      question: "Como indico amigos?",
      answer: "No menu 'Código', você encontra seu link de indicação exclusivo. Compartilhe com amigos e ganhe bônus quando eles realizarem o primeiro depósito."
    },
    {
      question: "Qual o depósito mínimo?",
      answer: "O depósito mínimo é de R$ 30,00. Valores menores não serão processados pelo sistema."
    },
    {
      question: "Posso ter mais de um plano ativo?",
      answer: "Sim! Você pode investir em múltiplos planos simultaneamente. Cada plano funciona de forma independente."
    },
    {
      question: "Como altero minha senha?",
      answer: "Acesse o Perfil > Alterar Senha. Você precisará informar a senha atual e a nova senha desejada."
    }
  ];

  const contactOptions = [
    {
      icon: MessageCircle,
      title: "WhatsApp",
      description: "Atendimento rápido",
      time: "Resposta em minutos",
      action: handleWhatsApp,
      color: "bg-green-500"
    },
    {
      icon: Mail,
      title: "E-mail",
      description: "suporte@debeers.com.br",
      time: "Resposta em 24h",
      action: handleEmail,
      color: "bg-primary"
    }
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-b from-primary to-primary/90 pt-12 pb-8 px-4">
        <div className="max-w-md mx-auto">
          {/* Back Button */}
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-primary-foreground/80 hover:text-primary-foreground mb-6 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Voltar</span>
          </button>

          {/* Title Section */}
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary-foreground/10 backdrop-blur-sm flex items-center justify-center border border-primary-foreground/20">
              <HelpCircle className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-primary-foreground mb-2">
              Central de Suporte
            </h1>
            <p className="text-primary-foreground/70 text-sm">
              Estamos aqui para ajudar você
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 pb-28 overflow-y-auto">
        <div className="max-w-md mx-auto">
          <Tabs defaultValue="faq" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="faq" className="text-xs sm:text-sm">
                <FileQuestion className="h-4 w-4 mr-1.5" />
                FAQ
              </TabsTrigger>
              <TabsTrigger value="contact" className="text-xs sm:text-sm">
                <MessageCircle className="h-4 w-4 mr-1.5" />
                Contato
              </TabsTrigger>
              <TabsTrigger value="ticket" className="text-xs sm:text-sm">
                <Send className="h-4 w-4 mr-1.5" />
                Chamado
              </TabsTrigger>
            </TabsList>

            {/* FAQ Tab */}
            <TabsContent value="faq" className="space-y-4">
              <Card className="border-border/50 shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <FileQuestion className="h-5 w-5 text-primary" />
                    Perguntas Frequentes
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <Accordion type="single" collapsible className="w-full">
                    {faqItems.map((item, index) => (
                      <AccordionItem key={index} value={`item-${index}`}>
                        <AccordionTrigger className="text-left text-sm hover:text-primary">
                          {item.question}
                        </AccordionTrigger>
                        <AccordionContent className="text-muted-foreground text-sm">
                          {item.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Contact Tab */}
            <TabsContent value="contact" className="space-y-4">
              <Card className="border-border/50 shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Phone className="h-5 w-5 text-primary" />
                    Canais de Atendimento
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {contactOptions.map((option, index) => {
                    const Icon = option.icon;
                    return (
                      <button
                        key={index}
                        onClick={option.action}
                        className="w-full flex items-center gap-4 p-4 rounded-xl bg-muted/50 hover:bg-muted transition-colors group"
                      >
                        <div className={`${option.color} w-12 h-12 rounded-xl flex items-center justify-center shadow-md`}>
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex-1 text-left">
                          <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                            {option.title}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {option.description}
                          </p>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {option.time}
                        </div>
                      </button>
                    );
                  })}
                </CardContent>
              </Card>

              {/* Operating Hours */}
              <Card className="border-border/50 shadow-sm">
                <CardContent className="py-4">
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium text-foreground">Horário de Atendimento</p>
                      <p className="text-sm text-muted-foreground">
                        Segunda a Sexta: 09:00 - 18:00
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Ticket Tab */}
            <TabsContent value="ticket" className="space-y-4">
              <Card className="border-border/50 shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Send className="h-5 w-5 text-primary" />
                    Abrir Chamado
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Descreva seu problema ou dúvida e nossa equipe responderá o mais breve possível.
                  </p>
                  
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">
                        Assunto
                      </label>
                      <Input
                        placeholder="Ex: Dúvida sobre saque"
                        value={subject}
                        onChange={(e) => {
                          setSubject(e.target.value);
                          if (errors.subject) setErrors(prev => ({ ...prev, subject: undefined }));
                        }}
                        className={`bg-muted/50 ${errors.subject ? 'border-destructive' : ''}`}
                        maxLength={200}
                      />
                      {errors.subject && (
                        <p className="text-xs text-destructive mt-1">{errors.subject}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">{subject.length}/200</p>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">
                        Mensagem
                      </label>
                      <Textarea
                        placeholder="Descreva detalhadamente sua dúvida ou problema..."
                        value={message}
                        onChange={(e) => {
                          setMessage(e.target.value);
                          if (errors.message) setErrors(prev => ({ ...prev, message: undefined }));
                        }}
                        className={`bg-muted/50 min-h-[120px] resize-none ${errors.message ? 'border-destructive' : ''}`}
                        maxLength={2000}
                      />
                      {errors.message && (
                        <p className="text-xs text-destructive mt-1">{errors.message}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">{message.length}/2000</p>
                    </div>
                  </div>

                  <Button 
                    onClick={handleSendMessage}
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-foreground mr-2" />
                    ) : (
                      <Send className="h-4 w-4 mr-2" />
                    )}
                    {isSubmitting ? "Enviando..." : "Enviar Mensagem"}
                  </Button>
                </CardContent>
              </Card>

              {/* Response Time Info */}
              <Card className="border-primary/20 bg-primary/5 shadow-sm">
                <CardContent className="py-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Clock className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground text-sm">Tempo de Resposta</p>
                      <p className="text-xs text-muted-foreground">
                        Nossa equipe responde em até 24 horas úteis. Você receberá uma notificação quando houver resposta.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* De Beers Branding */}
          <div className="mt-8 text-center">
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <Diamond className="h-4 w-4" />
              <span className="text-sm">De Beers Investimentos</span>
              <Diamond className="h-4 w-4" />
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
};

export default Support;
