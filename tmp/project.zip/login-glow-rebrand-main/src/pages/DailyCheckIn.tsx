import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Gift, Flame, Star, Calendar, CheckCircle2, Sparkles, Wallet } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/BottomNavigation";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const DailyCheckIn = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [hasClaimedToday, setHasClaimedToday] = useState(false);
  const [streak, setStreak] = useState(0);
  const [totalEarned, setTotalEarned] = useState(0);
  const [investmentBalance, setInvestmentBalance] = useState(0);
  const [nextClaimTime, setNextClaimTime] = useState<Date | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isClaiming, setIsClaiming] = useState(false);

  const dailyPrize = 0.50;

  // Fetch user check-in data from database
  useEffect(() => {
    const fetchCheckInData = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          navigate("/");
          return;
        }

        // Get user balance
        const { data: balanceData } = await supabase
          .from("user_balances")
          .select("investment_balance")
          .eq("user_id", user.id)
          .maybeSingle();

        if (balanceData) {
          setInvestmentBalance(Number(balanceData.investment_balance));
        }

        // Get today's check-in status
        const today = new Date().toISOString().split("T")[0];
        const { data: todayCheckin } = await supabase
          .from("daily_checkins")
          .select("*")
          .eq("user_id", user.id)
          .eq("checkin_date", today)
          .maybeSingle();

        if (todayCheckin) {
          setHasClaimedToday(true);
          // Set next claim time to tomorrow at midnight
          const tomorrow = new Date();
          tomorrow.setDate(tomorrow.getDate() + 1);
          tomorrow.setHours(0, 0, 0, 0);
          setNextClaimTime(tomorrow);
        }

        // Get total check-ins and calculate streak/total
        const { data: allCheckins } = await supabase
          .from("daily_checkins")
          .select("checkin_date, amount")
          .eq("user_id", user.id)
          .order("checkin_date", { ascending: false });

        if (allCheckins && allCheckins.length > 0) {
          // Calculate total earned
          const total = allCheckins.reduce((sum, c) => sum + Number(c.amount), 0);
          setTotalEarned(total);

          // Calculate streak (consecutive days including today)
          let streakCount = 0;
          const sortedDates = allCheckins.map(c => new Date(c.checkin_date)).sort((a, b) => b.getTime() - a.getTime());
          
          for (let i = 0; i < sortedDates.length; i++) {
            const expectedDate = new Date();
            expectedDate.setDate(expectedDate.getDate() - i);
            expectedDate.setHours(0, 0, 0, 0);
            
            const checkinDate = new Date(sortedDates[i]);
            checkinDate.setHours(0, 0, 0, 0);
            
            if (checkinDate.getTime() === expectedDate.getTime()) {
              streakCount++;
            } else {
              break;
            }
          }
          setStreak(streakCount);
        }
      } catch (error) {
        console.error("Error fetching check-in data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCheckInData();
  }, [navigate]);

  const handleClaim = async () => {
    setIsClaiming(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Erro",
          description: "Você precisa estar logado para resgatar o prêmio.",
          variant: "destructive",
        });
        return;
      }

      // Use secure RPC function instead of direct table manipulation
      // This prevents users from directly modifying their balance
      const { data, error } = await supabase.rpc('claim_daily_checkin');

      if (error) {
        console.error("Error claiming check-in:", error);
        toast({
          title: "Erro",
          description: "Não foi possível resgatar o prêmio. Tente novamente.",
          variant: "destructive",
        });
        return;
      }

      // Type the response from RPC
      const response = data as { 
        success: boolean; 
        error?: string; 
        message?: string; 
        new_balance?: number; 
        amount?: number; 
      };

      // Handle RPC response
      if (!response.success) {
        if (response.error === 'already_claimed') {
          toast({
            title: "Já resgatado",
            description: response.message || "Você já resgatou o prêmio de hoje!",
            variant: "destructive",
          });
          setHasClaimedToday(true);
        } else {
          toast({
            title: "Erro",
            description: response.message || "Não foi possível resgatar o prêmio.",
            variant: "destructive",
          });
        }
        return;
      }

      // Update state with server response
      setInvestmentBalance(Number(response.new_balance));
      setStreak(prev => prev + 1);
      setTotalEarned(prev => prev + Number(response.amount));
      setHasClaimedToday(true);
      setShowSuccess(true);

      // Set next claim time
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);
      setNextClaimTime(tomorrow);

      toast({
        title: "🎉 Parabéns!",
        description: `R$ ${Number(response.amount).toFixed(2)} creditado no seu saldo!`,
      });
    } catch (error) {
      console.error("Error claiming check-in:", error);
      toast({
        title: "Erro",
        description: "Não foi possível resgatar o prêmio. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsClaiming(false);
    }
  };

  const formatNextClaimTime = () => {
    if (!nextClaimTime) return "";
    const options: Intl.DateTimeFormatOptions = { 
      day: "numeric", 
      month: "long", 
      hour: "2-digit", 
      minute: "2-digit" 
    };
    return nextClaimTime.toLocaleDateString("pt-BR", options);
  };

  // Get last 7 days for calendar
  const getLast7Days = () => {
    const days = [];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      days.push({
        date: date,
        label: `${date.getDate().toString().padStart(2, "0")}/${(date.getMonth() + 1).toString().padStart(2, "0")}`,
        isToday: i === 0,
        isClaimed: i > 0 || hasClaimedToday
      });
    }
    return days;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-primary text-primary-foreground p-4">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1">
            <ArrowLeft className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold">Prêmio Diário</h1>
        </div>
      </header>

      <main className="flex-1 p-4 pb-24 overflow-y-auto space-y-4">
        {/* Investment Balance Card */}
        <Card className="bg-gradient-to-r from-primary to-primary/80 border-0">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                <Wallet className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <p className="text-primary-foreground/70 text-sm">Saldo p/ Investir</p>
                <p className="text-2xl font-bold text-primary-foreground">
                  R$ {investmentBalance.toFixed(2)}
                </p>
              </div>
            </div>
            <p className="text-primary-foreground/60 text-xs mt-2">
              💡 O prêmio é creditado imediatamente ao fazer o check-in
            </p>
          </CardContent>
        </Card>

        {/* Success Message */}
        {showSuccess && (
          <Card className="bg-primary/10 border-primary/30 animate-fade-in">
            <CardContent className="p-4">
              <p className="text-foreground font-medium">🎉 Parabéns!</p>
              <p className="text-muted-foreground text-sm">R$ {dailyPrize.toFixed(2)} creditado no seu saldo!</p>
            </CardContent>
          </Card>
        )}

        {/* Main Claim Card */}
        <Card className="border-primary/20 overflow-hidden">
          <CardContent className="p-6 bg-gradient-to-b from-primary/5 to-primary/10">
            {hasClaimedToday ? (
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-24 h-24 rounded-full border-4 border-primary flex items-center justify-center">
                  <CheckCircle2 className="h-12 w-12 text-primary" />
                </div>
                
                <div>
                  <h2 className="text-2xl font-bold text-foreground">Prêmio Resgatado!</h2>
                  <p className="text-muted-foreground mt-1">Você já resgatou o prêmio de hoje</p>
                </div>

                <div className="w-full bg-secondary/50 rounded-lg p-4 mt-4">
                  <p className="text-muted-foreground text-sm">Próximo prêmio em</p>
                  <p className="text-lg font-bold text-foreground">{formatNextClaimTime()}</p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
                  <Gift className="h-12 w-12 text-primary" />
                </div>
                
                <div>
                  <h2 className="text-2xl font-bold text-foreground">Resgate seu Prêmio!</h2>
                  <p className="text-muted-foreground mt-1">Clique para resgatar R$ {dailyPrize.toFixed(2)}</p>
                </div>

                <Button 
                  onClick={handleClaim}
                  disabled={isClaiming}
                  className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-bold"
                >
                  {isClaiming ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary-foreground" />
                  ) : (
                    <>
                      <Gift className="mr-2 h-5 w-5" />
                      Resgatar Prêmio
                    </>
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="bg-primary/10 border-primary/20">
            <CardContent className="p-4 text-center">
              <div className="w-10 h-10 mx-auto rounded-lg bg-primary/20 flex items-center justify-center mb-2">
                <Gift className="h-5 w-5 text-primary" />
              </div>
              <p className="text-xs text-muted-foreground mb-1">Prêmio</p>
              <p className="text-lg font-bold text-primary">R$ {dailyPrize.toFixed(2)}</p>
            </CardContent>
          </Card>

          <Card className="bg-primary/10 border-primary/20">
            <CardContent className="p-4 text-center">
              <div className="w-10 h-10 mx-auto rounded-lg bg-primary/20 flex items-center justify-center mb-2">
                <Flame className="h-5 w-5 text-primary" />
              </div>
              <p className="text-xs text-muted-foreground mb-1">Sequência</p>
              <p className="text-lg font-bold text-primary">{streak} dias</p>
            </CardContent>
          </Card>

          <Card className="bg-primary/10 border-primary/20">
            <CardContent className="p-4 text-center">
              <div className="w-10 h-10 mx-auto rounded-lg bg-primary/20 flex items-center justify-center mb-2">
                <Star className="h-5 w-5 text-primary" />
              </div>
              <p className="text-xs text-muted-foreground mb-1">Total</p>
              <p className="text-lg font-bold text-primary">R$ {totalEarned.toFixed(2)}</p>
            </CardContent>
          </Card>
        </div>

        {/* How it Works */}
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-bold text-foreground">Como Funciona?</h3>
            </div>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-primary">1</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Resgate <span className="text-primary font-medium">R$ {dailyPrize.toFixed(2)}</span> todos os dias
                </p>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-primary">2</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  O valor é creditado <span className="text-primary font-medium">imediatamente</span> no seu saldo
                </p>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-primary">3</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Mantenha sua <span className="text-primary font-medium">sequência diária</span> ativa
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Last 7 Days Calendar */}
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                <Calendar className="h-5 w-5 text-muted-foreground" />
              </div>
              <h3 className="font-bold text-foreground">Últimos 7 Dias</h3>
            </div>

            <div className="flex gap-2 overflow-x-auto pb-2">
              {getLast7Days().map((day, index) => (
                <div 
                  key={index}
                  className={`flex-shrink-0 w-14 h-16 rounded-lg flex flex-col items-center justify-center ${
                    day.isClaimed 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {day.isClaimed ? (
                    <CheckCircle2 className="h-5 w-5 mb-1" />
                  ) : (
                    <div className="w-5 h-5 rounded-full border-2 border-current mb-1" />
                  )}
                  <span className="text-xs font-medium">{day.label}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>

      <BottomNavigation />
    </div>
  );
};

export default DailyCheckIn;
