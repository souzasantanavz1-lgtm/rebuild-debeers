import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Filter } from "lucide-react";
import BottomNavigation from "@/components/BottomNavigation";

type FilterType = "all" | "deposits" | "withdrawals" | "earnings" | "commissions";

interface FilterTab {
  id: FilterType;
  label: string;
}

const filterTabs: FilterTab[] = [
  { id: "all", label: "Todos" },
  { id: "deposits", label: "Depósitos" },
  { id: "withdrawals", label: "Saques" },
  { id: "earnings", label: "Rendimentos" },
  { id: "commissions", label: "Comissões" },
];

const Statement = () => {
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState<FilterType>("all");

  // Mock data - will be replaced with real data from database
  const transactions: any[] = [];
  const totalBalance = 0;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-b from-primary to-primary/80 pt-4 pb-6 px-4">
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={() => navigate("/profile")}
            className="p-2 rounded-full hover:bg-primary-foreground/10 transition-colors"
          >
            <ArrowLeft className="h-6 w-6 text-primary-foreground" />
          </button>
          <h1 className="text-xl font-bold text-primary-foreground">Extrato</h1>
        </div>

        {/* Balance Card */}
        <div className="bg-primary/40 backdrop-blur-sm rounded-2xl p-6 border border-primary-foreground/10">
          <p className="text-primary-foreground/70 text-sm mb-1">Saldo Total Movimentado</p>
          <p className="text-3xl font-bold text-primary-foreground">
            R$ {totalBalance.toFixed(2).replace(".", ",")}
          </p>
        </div>
      </header>

      {/* Filter Tabs */}
      <div className="px-4 py-4 overflow-x-auto">
        <div className="flex gap-2 min-w-max">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeFilter === tab.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Transactions List */}
      <main className="flex-1 px-4 pb-24 overflow-y-auto">
        <div className="bg-card rounded-2xl p-6 shadow-sm border border-border">
          {transactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Filter className="h-8 w-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground text-lg">
                Nenhuma transação encontrada
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {transactions.map((transaction, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-xl"
                >
                  <div>
                    <p className="font-medium text-foreground">{transaction.type}</p>
                    <p className="text-sm text-muted-foreground">{transaction.date}</p>
                  </div>
                  <p className={`font-bold ${transaction.amount > 0 ? "text-green-500" : "text-red-500"}`}>
                    R$ {Math.abs(transaction.amount).toFixed(2).replace(".", ",")}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
};

export default Statement;
