import { useState, useEffect, lazy, Suspense } from "react";
import { supabase } from "@/integrations/supabase/client";
import BottomNavigation from "@/components/BottomNavigation";
import DashboardHeader from "@/components/dashboard/DashboardHeader";

// Lazy load heavy components
const WelcomeCard = lazy(() => import("@/components/dashboard/WelcomeCard"));
const HeroCarousel = lazy(() => import("@/components/dashboard/HeroCarousel"));
const QuickActions = lazy(() => import("@/components/dashboard/QuickActions"));
const RecentGains = lazy(() => import("@/components/dashboard/RecentGains"));
const DepositCTA = lazy(() => import("@/components/dashboard/DepositCTA"));

const WELCOME_DISMISSED_KEY = "de-beers-welcome-dismissed";

// Lightweight loading skeleton
const ContentSkeleton = () => (
  <div className="flex-1 bg-secondary p-4 space-y-4">
    <div className="bg-card rounded-xl p-4 h-48 animate-pulse" />
    <div className="bg-card rounded-xl p-4 h-32 animate-pulse" />
    <div className="bg-card rounded-xl p-4 h-24 animate-pulse" />
  </div>
);

const Dashboard = () => {
  const [showWelcomeCard, setShowWelcomeCard] = useState(() => {
    return localStorage.getItem(WELCOME_DISMISSED_KEY) !== "true";
  });
  const [investmentBalance, setInvestmentBalance] = useState(0);

  // Fetch user balance from database
  useEffect(() => {
    const fetchBalance = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase
          .from("user_balances")
          .select("investment_balance")
          .eq("user_id", user.id)
          .maybeSingle();
        
        if (data) {
          setInvestmentBalance(Number(data.investment_balance));
        }
      }
    };

    fetchBalance();
    
    // Re-fetch balance when page becomes visible
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        fetchBalance();
      }
    };
    
    const handleFocus = () => fetchBalance();
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
    };
  }, []);

  const handleWelcomeClose = () => {
    localStorage.setItem(WELCOME_DISMISSED_KEY, "true");
    setShowWelcomeCard(false);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col relative overflow-hidden">
      {/* Header - Always render immediately */}
      <DashboardHeader balance={investmentBalance} />

      {/* Main Content */}
      <main className={`relative z-10 flex-1 flex flex-col pb-20 overflow-y-auto ${showWelcomeCard ? 'items-center justify-center p-4 pt-8 md:pt-4 bg-primary/40' : ''}`}>
        {showWelcomeCard ? (
          <Suspense fallback={<div className="w-full max-w-md h-96 bg-card rounded-xl animate-pulse" />}>
            <WelcomeCard onClose={handleWelcomeClose} />
          </Suspense>
        ) : (
          /* Main Dashboard View */
          <div className="w-full animate-fade-in flex flex-col min-h-0">
            {/* Hero Carousel */}
            <Suspense fallback={<div className="w-full h-36 sm:h-44 bg-primary/10 animate-pulse" />}>
              <HeroCarousel />
            </Suspense>

            {/* Divider Line */}
            <div className="w-full h-1 bg-primary/20" />

            {/* Content Section */}
            <Suspense fallback={<ContentSkeleton />}>
              <div className="flex-1 bg-secondary p-4 space-y-6 overflow-y-auto">
                <div className="max-w-4xl mx-auto space-y-6">
                  <QuickActions />
                  <RecentGains />
                  <DepositCTA />
                </div>
              </div>
            </Suspense>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
};

export default Dashboard;
