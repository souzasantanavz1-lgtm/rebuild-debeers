import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { 
  Lock, 
  Package, 
  FileText, 
  MessageCircle, 
  Users, 
  Download, 
  LogOut,
  Headphones
} from "lucide-react";
import BottomNavigation from "@/components/BottomNavigation";
import ProfileHeader from "@/components/profile/ProfileHeader";
import QuickActionsGrid from "@/components/profile/QuickActionsGrid";
import ProfileFooter from "@/components/profile/ProfileFooter";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const Profile = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [investmentBalance, setInvestmentBalance] = useState(0);

  const fetchBalance = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from("user_balances")
        .select("investment_balance")
        .eq("user_id", user.id)
        .maybeSingle();
      
      if (data) {
        setInvestmentBalance(Number(data.investment_balance));
      }
    }
  };

  useEffect(() => {
    fetchBalance();
    
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        fetchBalance();
      }
    };
    
    const handleFocus = () => fetchBalance();
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
    };
  }, []);

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      // Use generic error message to avoid exposing internal details
      console.error('Logout error:', error.message);
      toast({
        title: "Erro ao sair",
        description: "Não foi possível fazer logout. Tente novamente.",
        variant: "destructive",
      });
    } else {
      navigate("/");
    }
  };

  const handleWhatsAppGroup = (groupNumber: number) => {
    toast({
      title: `Grupo ${groupNumber.toString().padStart(2, '0')}`,
      description: "Link do grupo será disponibilizado em breve.",
    });
  };

  const handleDownload = () => {
    toast({
      title: "Em breve",
      description: "Download do app",
    });
  };

  const quickActions = [
    { 
      icon: Lock, 
      label: "alterar senha", 
      color: "bg-primary",
      action: () => navigate("/change-password")
    },
    { 
      icon: Package, 
      label: "investimentos", 
      color: "bg-orange-500",
      action: () => navigate("/plans")
    },
    { 
      icon: FileText, 
      label: "extrato", 
      color: "bg-purple-400",
      action: () => navigate("/statement")
    },
    { 
      icon: Headphones, 
      label: "suporte", 
      color: "bg-primary",
      action: () => navigate("/support")
    },
    { 
      icon: MessageCircle, 
      label: "grupo 01", 
      color: "bg-cyan-500",
      action: () => handleWhatsAppGroup(1)
    },
    { 
      icon: MessageCircle, 
      label: "grupo 02", 
      color: "bg-cyan-500",
      action: () => handleWhatsAppGroup(2)
    },
    { 
      icon: Users, 
      label: "código", 
      color: "bg-pink-500",
      action: () => navigate("/referral")
    },
    { 
      icon: Download, 
      label: "download", 
      color: "bg-yellow-500",
      action: handleDownload
    },
    { 
      icon: LogOut, 
      label: "sair", 
      color: "bg-gray-600",
      action: handleLogout
    },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <ProfileHeader investmentBalance={investmentBalance} />

      <main className="flex-1 p-4 pb-24 overflow-y-auto">
        <div className="max-w-md mx-auto">
          <QuickActionsGrid actions={quickActions} />
          <ProfileFooter />
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
};

export default Profile;
