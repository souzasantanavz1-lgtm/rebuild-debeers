import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  ArrowLeft, 
  Copy, 
  Share2, 
  Users, 
  TrendingUp,
  Medal
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/BottomNavigation";

const ReferralProgram = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Mock data - will be replaced with real data
  const referralCode = ""; // Empty as shown in image
  const level1Count = 0;
  const level2Count = 0;
  const level3Count = 0;
  const totalEarnings = 0;

  const handleCopyCode = () => {
    if (referralCode) {
      navigator.clipboard.writeText(referralCode);
      toast({
        title: "Copiado!",
        description: "Código de indicação copiado para a área de transferência.",
      });
    } else {
      toast({
        title: "Aviso",
        description: "Código de indicação será gerado em breve.",
      });
    }
  };

  const handleShareLink = () => {
    const shareUrl = `https://debeers.com/register?ref=${referralCode}`;
    if (navigator.share && referralCode) {
      navigator.share({
        title: "De Beers Investimentos",
        text: "Junte-se a mim na De Beers e ganhe bônus!",
        url: shareUrl,
      });
    } else {
      toast({
        title: "Compartilhar",
        description: "Link de indicação será disponibilizado em breve.",
      });
    }
  };

  const commissionTable = [
    { 
      title: "Primeira Compra",
      levels: [
        { level: 1, emoji: "🥇", percentage: 15 },
        { level: 2, emoji: "🥈", percentage: 2 },
        { level: 3, emoji: "🥉", percentage: 1 },
      ]
    },
    {
      title: "Segunda Compra em Diante",
      levels: [
        { level: 1, emoji: "🥇", percentage: 8 },
        { level: 2, emoji: "🥈", percentage: 1 },
        { level: 3, emoji: "🥉", percentage: 1 },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-primary pt-4 pb-4 px-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/profile")}
            className="p-2 rounded-full hover:bg-primary-foreground/10 transition-colors"
          >
            <ArrowLeft className="h-6 w-6 text-primary-foreground" />
          </button>
          <h1 className="text-xl font-bold text-primary-foreground">Programa de Indicação</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 pb-24 overflow-y-auto space-y-6">
        {/* Referral Code Card */}
        <div className="bg-amber-50 rounded-2xl p-6 border border-amber-200">
          <p className="text-center text-muted-foreground mb-3">Seu Código de Indicação</p>
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={referralCode}
              readOnly
              placeholder=""
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-white text-foreground text-center font-mono"
            />
            <button
              onClick={handleCopyCode}
              className="px-4 py-3 rounded-xl border border-border bg-white hover:bg-muted transition-colors"
            >
              <Copy className="h-5 w-5 text-muted-foreground" />
            </button>
          </div>
          <Button
            onClick={handleShareLink}
            className="w-full bg-amber-400 hover:bg-amber-500 text-primary font-semibold py-6"
          >
            <Share2 className="h-5 w-5 mr-2" />
            Compartilhar Link
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          {/* Level 1 */}
          <div className="bg-card rounded-2xl p-4 border border-border text-center">
            <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
            <p className="text-2xl font-bold text-foreground">{level1Count}</p>
            <p className="text-sm text-muted-foreground">Nível 1</p>
          </div>

          {/* Level 2 */}
          <div className="bg-card rounded-2xl p-4 border border-border text-center">
            <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
            <p className="text-2xl font-bold text-foreground">{level2Count}</p>
            <p className="text-sm text-muted-foreground">Nível 2</p>
          </div>

          {/* Level 3 */}
          <div className="bg-card rounded-2xl p-4 border border-border text-center">
            <TrendingUp className="h-8 w-8 mx-auto mb-2 text-amber-500" />
            <p className="text-2xl font-bold text-foreground">{level3Count}</p>
            <p className="text-sm text-muted-foreground">Nível 3</p>
          </div>

          {/* Earnings */}
          <div className="bg-primary/90 rounded-2xl p-4 text-center">
            <p className="text-primary-foreground/80 text-sm mb-1">Ganhos</p>
            <p className="text-2xl font-bold text-primary-foreground">
              R$ {totalEarnings.toFixed(2).replace(".", ",")}
            </p>
          </div>
        </div>

        {/* Commission Table */}
        <div className="bg-card rounded-2xl p-6 border border-border">
          <h3 className="text-lg font-bold text-foreground mb-4">Tabela de Comissões</h3>
          
          {commissionTable.map((section, sectionIndex) => (
            <div key={sectionIndex} className="mb-4 last:mb-0">
              <p className="text-sm text-muted-foreground mb-2">{section.title}</p>
              <div className="space-y-2">
                {section.levels.map((item) => (
                  <div 
                    key={`${sectionIndex}-${item.level}`}
                    className="flex items-center justify-between px-4 py-3 bg-amber-50 rounded-xl"
                  >
                    <span className="flex items-center gap-2 text-foreground">
                      Nível {item.level} <span>{item.emoji}</span>
                    </span>
                    <span className="font-bold text-primary">{item.percentage}%</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* How it works */}
        <div className="bg-amber-50 rounded-2xl p-6 border border-amber-200">
          <h3 className="text-lg font-bold text-foreground mb-4">Como Funciona?</h3>
          <ul className="space-y-2 text-sm text-foreground">
            <li>
              <strong>• Nível 1:</strong> Pessoas que você indicou diretamente
            </li>
            <li>
              <strong>• Nível 2:</strong> Pessoas indicadas pelos seus indicados
            </li>
            <li>
              <strong>• Nível 3:</strong> Pessoas indicadas pelos indicados de nível 2
            </li>
          </ul>
          <div className="mt-4 pt-4 border-t border-amber-200">
            <p className="text-sm text-foreground">
              <strong>Importante:</strong> As comissões são calculadas sobre o valor do pacote comprado, não sobre o depósito.
            </p>
          </div>
        </div>

        {/* My Network */}
        <div className="bg-card rounded-2xl p-6 border border-border">
          <h3 className="text-lg font-bold text-foreground">Minha Rede (0)</h3>
          <p className="text-sm text-muted-foreground mt-2">
            Nenhum indicado encontrado ainda.
          </p>
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
};

export default ReferralProgram;
