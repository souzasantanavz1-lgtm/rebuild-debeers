import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Wallet, Clock, AlertTriangle, Info, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import BottomNavigation from "@/components/BottomNavigation";
import deBeersLogo from "@/assets/de-beers-logo.svg";
import { withdrawSchema, validatePixKey } from "@/lib/validations/financial";
import { useToast } from "@/hooks/use-toast";

const Withdraw = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [cpf, setCpf] = useState("");
  const [pixKeyType, setPixKeyType] = useState("cpf");
  const [pixKey, setPixKey] = useState("");
  const [errors, setErrors] = useState<{ amount?: string; cpf?: string; pixKeyType?: string; pixKey?: string }>({});

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "");
    const formatted = value ? (parseInt(value) / 100).toFixed(2) : "";
    setAmount(formatted);
    setErrors((prev) => ({ ...prev, amount: undefined }));
  };

  const formatCPF = (value: string) => {
    const digits = value.replace(/\D/g, "").slice(0, 11);
    if (digits.length <= 3) return digits;
    if (digits.length <= 6) return `${digits.slice(0, 3)}.${digits.slice(3)}`;
    if (digits.length <= 9) return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
    return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCpf(formatCPF(e.target.value));
    setErrors((prev) => ({ ...prev, cpf: undefined }));
  };

  const handlePixKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPixKey(e.target.value);
    setErrors((prev) => ({ ...prev, pixKey: undefined }));
  };

  const handlePixKeyTypeChange = (value: string) => {
    setPixKeyType(value);
    setPixKey("");
    setErrors((prev) => ({ ...prev, pixKey: undefined, pixKeyType: undefined }));
  };

  const getPixKeyPlaceholder = () => {
    switch (pixKeyType) {
      case "cpf":
        return "000.000.000-00";
      case "email":
        return "email@exemplo.com";
      case "phone":
        return "(00) 00000-0000";
      case "random":
        return "Chave aleatória";
      default:
        return "Digite sua chave PIX";
    }
  };

  const handleSubmit = () => {
    const numAmount = parseFloat(amount) || 0;
    
    // Validate with zod schema
    const result = withdrawSchema.safeParse({
      amount: numAmount,
      cpf: cpf,
      pixKeyType: pixKeyType,
      pixKey: pixKey,
    });

    const fieldErrors: { amount?: string; cpf?: string; pixKeyType?: string; pixKey?: string } = {};

    if (!result.success) {
      result.error.errors.forEach((err) => {
        const field = err.path[0] as keyof typeof fieldErrors;
        fieldErrors[field] = err.message;
      });
    }

    // Additional PIX key type-specific validation
    if (!fieldErrors.pixKey) {
      const pixKeyError = validatePixKey(pixKeyType, pixKey);
      if (pixKeyError) {
        fieldErrors.pixKey = pixKeyError;
      }
    }

    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      toast({
        title: "Dados inválidos",
        description: "Por favor, corrija os campos destacados.",
        variant: "destructive",
      });
      return;
    }

    // Clear errors on success
    setErrors({});

    // TODO: Implement actual withdrawal functionality with backend
    toast({
      title: "Solicitação enviada",
      description: `Saque de R$ ${numAmount.toFixed(2)} solicitado com sucesso!`,
    });
  };

  const quickAmounts = [30, 50, 100, 200, 500];

  return (
    <div className="min-h-screen bg-secondary flex flex-col">
      {/* Header */}
      <header className="bg-primary text-primary-foreground px-4 py-3 flex items-center gap-3 flex-shrink-0">
        <button onClick={() => navigate(-1)} className="p-1 hover:bg-primary-foreground/10 rounded-full transition-colors flex-shrink-0">
          <ArrowLeft className="h-6 w-6" />
        </button>
        <h1 className="text-lg font-semibold">Solicitar Saque</h1>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 pb-24 space-y-4 overflow-y-auto">
        <div className="max-w-md mx-auto space-y-4">
          {/* Balance Card */}
          <div className="bg-gradient-to-r from-primary via-primary/90 to-primary/80 rounded-xl p-6 text-primary-foreground shadow-lg">
            <div className="flex items-center gap-2 mb-2">
              <Wallet className="h-5 w-5" />
              <span className="text-sm opacity-90">Saldo Disponível</span>
            </div>
            <p className="text-4xl font-bold">R$ 0.00</p>
          </div>

          {/* Info Card */}
          <div className="bg-card rounded-xl p-4 shadow-sm border border-border">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Info className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1">
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-primary"></span>
                    <span className="text-muted-foreground">Mín: R$ 30.00</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-primary"></span>
                    <span className="text-muted-foreground">Taxa: 10%</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-primary"></span>
                    <span className="text-muted-foreground">1 saque/dia</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-primary"></span>
                    <span className="text-muted-foreground">10h às 17h</span>
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4 text-primary" />
                  <span>Disponível todos os dias da semana</span>
                </div>
                <div className="mt-2 flex items-center gap-2 text-sm text-destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <span>Só saca com plano ativo</span>
                </div>
              </div>
            </div>
          </div>

          {/* Withdraw Form */}
          <div className="bg-card rounded-xl p-6 shadow-sm border border-border space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Quanto deseja sacar?</h2>
            
            {/* Amount Input */}
            <div className="space-y-2">
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-primary font-semibold text-lg">R$</span>
                <Input
                  type="text"
                  value={amount}
                  onChange={handleAmountChange}
                  placeholder="0.00"
                  className={`pl-12 h-14 text-xl font-semibold border-2 ${errors.amount ? "border-destructive focus:border-destructive" : "border-primary/20 focus:border-primary"}`}
                />
              </div>
              {errors.amount && (
                <p className="text-sm text-destructive flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.amount}
                </p>
              )}
            </div>

            {/* Quick Amount Buttons */}
            <div className="grid grid-cols-5 gap-2">
              {quickAmounts.map((value) => (
                <button
                  key={value}
                  onClick={() => {
                    setAmount(value.toFixed(2));
                    setErrors((prev) => ({ ...prev, amount: undefined }));
                  }}
                  className="py-2 px-3 bg-secondary rounded-lg text-sm font-medium text-foreground hover:bg-primary hover:text-primary-foreground transition-colors border border-border"
                >
                  {value}
                </button>
              ))}
            </div>

            {/* CPF Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">CPF do Titular</label>
              <Input
                type="text"
                value={cpf}
                onChange={handleCpfChange}
                placeholder="000.000.000-00"
                className={`h-12 border-2 ${errors.cpf ? "border-destructive focus:border-destructive" : "border-primary/20 focus:border-primary"}`}
              />
              {errors.cpf && (
                <p className="text-sm text-destructive flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.cpf}
                </p>
              )}
            </div>

            {/* PIX Key Type Select */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Tipo de Chave PIX</label>
              <Select value={pixKeyType} onValueChange={handlePixKeyTypeChange}>
                <SelectTrigger className={`h-12 border-2 ${errors.pixKeyType ? "border-destructive focus:border-destructive" : "border-primary/20 focus:border-primary"}`}>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cpf">CPF</SelectItem>
                  <SelectItem value="email">E-mail</SelectItem>
                  <SelectItem value="phone">Telefone</SelectItem>
                  <SelectItem value="random">Chave Aleatória</SelectItem>
                </SelectContent>
              </Select>
              {errors.pixKeyType && (
                <p className="text-sm text-destructive flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.pixKeyType}
                </p>
              )}
            </div>

            {/* PIX Key Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Chave PIX</label>
              <Input
                type="text"
                value={pixKey}
                onChange={handlePixKeyChange}
                placeholder={getPixKeyPlaceholder()}
                className={`h-12 border-2 ${errors.pixKey ? "border-destructive focus:border-destructive" : "border-primary/20 focus:border-primary"}`}
              />
              {errors.pixKey && (
                <p className="text-sm text-destructive flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.pixKey}
                </p>
              )}
            </div>

            {/* Submit Button */}
            <Button 
              onClick={handleSubmit}
              className="w-full h-14 bg-primary hover:bg-primary/90 text-primary-foreground text-lg font-semibold"
            >
              Solicitar Saque
            </Button>
          </div>

          {/* How it works */}
          <div className="bg-card rounded-xl p-4 shadow-sm border border-border">
            <h3 className="font-semibold text-foreground mb-3">Como funciona?</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
                <p>Insira o valor que deseja sacar (mínimo R$ 30)</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
                <p>Informe seu CPF e sua chave PIX para recebimento</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
                <p>Aguarde a aprovação (até 24h úteis)</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
};

export default Withdraw;
