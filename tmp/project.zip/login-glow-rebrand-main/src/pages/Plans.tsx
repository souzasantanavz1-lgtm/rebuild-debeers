import { useNavigate } from "react-router-dom";
import { ArrowLeft, Diamond, TrendingUp, Calendar, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import BottomNavigation from "@/components/BottomNavigation";
import LazyImage from "@/components/LazyImage";

// Import diamond images
import diamondBasic from "@/assets/diamond-basic.jpg";
import diamondCollection from "@/assets/diamond-collection.jpg";
import diamondVault from "@/assets/diamond-vault.jpg";
import diamondRough from "@/assets/diamond-rough.jpg";
import diamondJewel from "@/assets/diamond-jewel.jpg";
import diamondTreasure from "@/assets/diamond-treasure.jpg";
import diamondMine from "@/assets/diamond-mine.jpg";
import diamondTruck from "@/assets/diamond-truck.jpg";
import diamondDrill from "@/assets/diamond-drill.jpg";
import diamondProcessing from "@/assets/diamond-processing.jpg";
import diamondCutting from "@/assets/diamond-cutting.jpg";
import diamondUnderground from "@/assets/diamond-underground.jpg";
import diamondOpenpit from "@/assets/diamond-openpit.jpg";
import diamondDrilling from "@/assets/diamond-drilling.jpg";
import diamondRig from "@/assets/diamond-rig.jpg";

const Plans = () => {
  const navigate = useNavigate();

  const investmentPlans = [
    // Diamond Plans (replacing gold)
    {
      id: 1,
      name: "Diamante Bruto",
      emoji: "💎",
      image: diamondRough,
      investment: 20,
      dailyProfit: 5,
      cycle: 3,
      limit: 1,
      returnTotal: 35,
      profitPercent: 75,
    },
    {
      id: 2,
      name: "Diamante Lapidado",
      emoji: "💎",
      image: diamondBasic,
      investment: 50,
      dailyProfit: 10,
      cycle: 15,
      limit: 3,
      returnTotal: 150,
      profitPercent: 200,
    },
    {
      id: 3,
      name: "Diamante Brilhante",
      emoji: "💎",
      image: diamondJewel,
      investment: 100,
      dailyProfit: 32,
      cycle: 5,
      limit: 1,
      returnTotal: 160,
      profitPercent: 60,
    },
    {
      id: 4,
      name: "Cofre de Diamantes",
      emoji: "🔐",
      image: diamondVault,
      investment: 200,
      dailyProfit: 44,
      cycle: 10,
      limit: 3,
      returnTotal: 440,
      profitPercent: 120,
    },
    {
      id: 5,
      name: "Coleção De Beers",
      emoji: "💎",
      image: diamondCollection,
      investment: 450,
      dailyProfit: 90,
      cycle: 15,
      limit: 3,
      returnTotal: 1350,
      profitPercent: 200,
    },
    {
      id: 6,
      name: "Tesouro De Beers",
      emoji: "🏆",
      image: diamondTreasure,
      investment: 530,
      dailyProfit: 110,
      cycle: 15,
      limit: 3,
      returnTotal: 1650,
      profitPercent: 211,
    },
    {
      id: 7,
      name: "Mina de Diamantes",
      emoji: "⛏️",
      image: diamondOpenpit,
      investment: 625,
      dailyProfit: 137.5,
      cycle: 15,
      limit: 3,
      returnTotal: 2062.5,
      profitPercent: 230,
    },
    // Mining Equipment Plans (replacing old mining)
    {
      id: 8,
      name: "Extração Subterrânea",
      emoji: "⛏️",
      image: diamondUnderground,
      investment: 30,
      dailyProfit: 15,
      cycle: 3,
      limit: 1,
      returnTotal: 45,
      profitPercent: 50,
    },
    {
      id: 9,
      name: "Perfuração De Beers",
      emoji: "🔧",
      image: diamondDrilling,
      investment: 85,
      dailyProfit: 35,
      cycle: 3,
      limit: 3,
      returnTotal: 105,
      profitPercent: 24,
    },
    {
      id: 10,
      name: "Transporte de Diamantes",
      emoji: "🚚",
      image: diamondTruck,
      investment: 150,
      dailyProfit: 38,
      cycle: 5,
      limit: 5,
      returnTotal: 190,
      profitPercent: 27,
    },
    {
      id: 11,
      name: "Perfuratriz Premium",
      emoji: "⚙️",
      image: diamondRig,
      investment: 300,
      dailyProfit: 55,
      cycle: 7,
      limit: 5,
      returnTotal: 385,
      profitPercent: 28,
    },
    {
      id: 12,
      name: "Processamento De Beers",
      emoji: "🏭",
      image: diamondProcessing,
      investment: 650,
      dailyProfit: 80,
      cycle: 10,
      limit: 5,
      returnTotal: 800,
      profitPercent: 23,
    },
    {
      id: 13,
      name: "Lapidação Premium",
      emoji: "✨",
      image: diamondCutting,
      investment: 1500,
      dailyProfit: 200,
      cycle: 15,
      limit: 5,
      returnTotal: 3000,
      profitPercent: 100,
    },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-primary text-primary-foreground p-4">
        <div className="flex items-center gap-3 mb-3">
          <button onClick={() => navigate(-1)} className="p-1">
            <ArrowLeft className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold">Planos de Investimento</h1>
        </div>
        
        {/* Button for active plans - separate row on mobile */}
        <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-primary-foreground/15 hover:bg-primary-foreground/25 rounded-lg text-sm font-medium transition-colors border border-primary-foreground/20">
          <span>📊</span>
          <span>Ver Meus Planos Ativos</span>
        </button>
      </header>

      {/* Promotional Banner */}
      <div className="bg-gradient-to-r from-primary/90 to-primary/70 px-4 py-2.5">
        <div className="flex items-center justify-center gap-2 text-primary-foreground">
          <Diamond className="h-4 w-4" />
          <span className="text-xs font-medium">Invista em Diamantes e Lucre Diariamente!</span>
          <Diamond className="h-4 w-4" />
        </div>
      </div>

      {/* Plans Grid */}
      <main className="flex-1 p-4 pb-24 overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-6xl mx-auto">
          {investmentPlans.map((plan, index) => (
            <Card 
              key={plan.id} 
              className="overflow-hidden border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300 animate-fade-in hover-scale"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Plan Image */}
              <div className="relative h-40 overflow-hidden group">
                <LazyImage 
                  src={plan.image} 
                  alt={plan.name} 
                  className="w-full h-full"
                  skeletonClassName="rounded-none"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent pointer-events-none" />
                <div className="absolute bottom-3 left-3 flex items-center gap-2">
                  <span className="text-lg">{plan.emoji}</span>
                  <h3 className="text-white font-bold text-lg drop-shadow-lg">{plan.name}</h3>
                </div>
              </div>

              <CardContent className="p-4 space-y-3">
                {/* Investment Amount */}
                <div className="flex items-center justify-between bg-secondary/50 rounded-lg p-3">
                  <span className="text-sm text-muted-foreground">Investimento</span>
                  <span className="text-lg font-bold text-primary">
                    R$ {plan.investment.toFixed(2)}
                  </span>
                </div>

                {/* Daily Profit and Cycle */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-primary/10 rounded-lg p-3 border border-primary/20">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                      <TrendingUp className="h-3 w-3" />
                      <span>Lucro/dia</span>
                    </div>
                    <span className="text-primary font-bold">
                      R$ {plan.dailyProfit.toFixed(2)}
                    </span>
                  </div>
                  <div className="bg-primary/10 rounded-lg p-3 border border-primary/20">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                      <Calendar className="h-3 w-3" />
                      <span>Ciclo</span>
                    </div>
                    <span className="text-primary font-bold">{plan.cycle} dias</span>
                  </div>
                </div>

                {/* Limit */}
                <div className="flex items-center justify-center gap-2 bg-secondary/30 rounded-lg p-2 text-sm text-muted-foreground">
                  <ShoppingCart className="h-4 w-4" />
                  <span>Limite: {plan.limit} compra{plan.limit > 1 ? 's' : ''} por usuário</span>
                </div>

                {/* Total Return */}
                <div className="flex items-center justify-between bg-secondary/50 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                      <Diamond className="h-3 w-3 text-primary" />
                    </div>
                    <span className="text-sm text-muted-foreground">Retorno Total</span>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold text-primary">
                      R$ {plan.returnTotal.toFixed(2)}
                    </span>
                    <p className="text-xs text-primary/70">+{plan.profitPercent}% de lucro</p>
                  </div>
                </div>

                {/* Buy Button */}
                <Button className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-bold transition-all duration-200 hover:shadow-md">
                  <Diamond className="mr-2 h-5 w-5" />
                  Investir Agora
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
};

export default Plans;
