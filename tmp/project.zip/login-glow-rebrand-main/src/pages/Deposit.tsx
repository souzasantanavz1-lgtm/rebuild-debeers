import { useState } from "react";
import { ArrowLeft, Sparkles, CreditCard, QrCode, HelpCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import BottomNavigation from "@/components/BottomNavigation";
import { depositSchema } from "@/lib/validations/financial";
import { useToast } from "@/hooks/use-toast";

const Deposit = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [cpf, setCpf] = useState("");
  const [errors, setErrors] = useState<{ amount?: string; cpf?: string }>({});

  const quickAmounts = [30, 50, 100, 200, 500];

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 3) return numbers;
    if (numbers.length <= 6) return `${numbers.slice(0, 3)}.${numbers.slice(3)}`;
    if (numbers.length <= 9) return `${numbers.slice(0, 3)}.${numbers.slice(3, 6)}.${numbers.slice(6)}`;
    return `${numbers.slice(0, 3)}.${numbers.slice(3, 6)}.${numbers.slice(6, 9)}-${numbers.slice(9, 11)}`;
  };

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCPF(e.target.value);
    if (formatted.length <= 14) {
      setCpf(formatted);
      setErrors((prev) => ({ ...prev, cpf: undefined }));
    }
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "");
    setAmount(value);
    setErrors((prev) => ({ ...prev, amount: undefined }));
  };

  const handleSubmit = () => {
    const numAmount = parseInt(amount) || 0;
    
    const result = depositSchema.safeParse({
      amount: numAmount,
      cpf: cpf,
    });

    if (!result.success) {
      const fieldErrors: { amount?: string; cpf?: string } = {};
      result.error.errors.forEach((err) => {
        if (err.path[0] === "amount") fieldErrors.amount = err.message;
        if (err.path[0] === "cpf") fieldErrors.cpf = err.message;
      });
      setErrors(fieldErrors);
      toast({
        title: "Dados inválidos",
        description: "Por favor, corrija os campos destacados.",
        variant: "destructive",
      });
      return;
    }

    // Clear errors on success
    setErrors({});
    
    // TODO: Implement actual deposit functionality with backend
    toast({
      title: "Gerando QR Code PIX",
      description: `Valor: R$ ${numAmount.toFixed(2)}`,
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="flex items-center gap-3 px-4 py-3 bg-card border-b border-border">
        <button onClick={() => navigate(-1)} className="text-foreground hover:text-primary transition-colors">
          <ArrowLeft className="h-6 w-6" />
        </button>
        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
          <CreditCard className="h-5 w-5 text-primary" />
        </div>
        <h1 className="text-lg font-semibold text-foreground">Recarregar Conta</h1>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 pb-24 overflow-y-auto">
        <div className="max-w-lg mx-auto space-y-4">
          {/* Hero Banner - De Beers Blue Style */}
          <div className="bg-gradient-to-r from-primary via-primary/80 to-primary/60 rounded-2xl p-6 text-primary-foreground">
            <div className="flex items-center gap-3">
              <Sparkles className="h-8 w-8" />
              <div>
                <h2 className="text-xl font-bold">Deposite e Invista</h2>
                <p className="text-sm opacity-90">Comece a lucrar hoje mesmo</p>
              </div>
            </div>
          </div>

          {/* Deposit Form Card */}
          <div className="bg-card rounded-2xl p-6 shadow-sm border border-border space-y-6">
            {/* Amount Input */}
            <div className="space-y-3">
              <label className="text-foreground font-medium">Quanto deseja depositar?</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-primary font-semibold">R$</span>
                <Input
                  type="text"
                  placeholder="0.00"
                  value={amount}
                  onChange={handleAmountChange}
                  className={`pl-12 h-12 text-lg ${errors.amount ? "border-destructive focus:border-destructive" : "border-border focus:border-primary"}`}
                />
              </div>
              {errors.amount && (
                <p className="text-sm text-destructive flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.amount}
                </p>
              )}

              {/* Quick Amount Buttons */}
              <div className="flex gap-2 flex-wrap">
                {quickAmounts.map((value) => (
                  <button
                    key={value}
                    onClick={() => {
                      setAmount(value.toString());
                      setErrors((prev) => ({ ...prev, amount: undefined }));
                    }}
                    className={`px-4 py-2 rounded-full border transition-all ${
                      amount === value.toString()
                        ? "bg-primary text-primary-foreground border-primary"
                        : "border-border text-foreground hover:border-primary hover:text-primary"
                    }`}
                  >
                    {value}
                  </button>
                ))}
              </div>

              <p className="text-sm text-muted-foreground flex items-center gap-1">
                <HelpCircle className="h-4 w-4" />
                Mínimo: R$ 30.00
              </p>
            </div>

            {/* CPF Input */}
            <div className="space-y-3">
              <label className="text-foreground font-medium">CPF do Titular</label>
              <div className="relative">
                <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="000.000.000-00"
                  value={cpf}
                  onChange={handleCPFChange}
                  className={`pl-12 h-12 ${errors.cpf ? "border-destructive focus:border-destructive" : "border-border focus:border-primary"}`}
                />
              </div>
              {errors.cpf && (
                <p className="text-sm text-destructive flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.cpf}
                </p>
              )}
            </div>

            {/* Generate PIX Button */}
            <Button 
              onClick={handleSubmit}
              className="w-full h-14 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground font-semibold text-lg"
            >
              <QrCode className="mr-2 h-6 w-6" />
              Gerar QR Code PIX
            </Button>
          </div>

          {/* How it Works Section */}
          <div className="bg-card rounded-2xl p-6 shadow-sm border border-border">
            <div className="flex items-center gap-2 mb-4">
              <HelpCircle className="h-5 w-5 text-primary" />
              <h3 className="font-bold text-foreground">Como funciona?</h3>
            </div>
            <ol className="space-y-3 text-sm text-muted-foreground">
              <li className="flex gap-3">
                <span className="text-primary font-bold">1.</span>
                Escolha o valor e informe seu CPF
              </li>
              <li className="flex gap-3">
                <span className="text-primary font-bold">2.</span>
                Será gerado um QR Code PIX instantâneo
              </li>
              <li className="flex gap-3">
                <span className="text-primary font-bold">3.</span>
                Pague pelo app do seu banco
              </li>
              <li className="flex gap-3">
                <span className="text-primary font-bold">4.</span>
                Saldo creditado automaticamente em até 2 minutos
              </li>
            </ol>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
};

export default Deposit;
