import deBeersLogo from "@/assets/de-beers-logo.svg";

interface DashboardHeaderProps {
  balance: number;
}

const DashboardHeader = ({ balance }: DashboardHeaderProps) => {
  return (
    <header className="relative z-10 flex items-center justify-between px-4 py-3 bg-primary text-primary-foreground flex-shrink-0">
      <img src={deBeersLogo} alt="De Beers Logo" className="h-10 w-auto brightness-0 invert" />
      <div className="text-right">
        <p className="text-xs opacity-80">Saldo p/ Investir</p>
        <p className="text-lg font-bold">R$ {balance.toFixed(2)}</p>
      </div>
    </header>
  );
};

export default DashboardHeader;
