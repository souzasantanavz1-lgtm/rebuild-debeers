import { useNavigate } from "react-router-dom";
import { CreditCard, ArrowRight } from "lucide-react";

const DepositCTA = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-secondary rounded-xl p-4 shadow-sm border border-primary/20">
      <button onClick={() => navigate("/deposit")} className="w-full flex items-center justify-between group">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <CreditCard className="h-5 w-5 text-primary" />
          </div>
          <div className="text-left">
            <p className="font-bold text-foreground">Depósito</p>
            <p className="text-sm text-muted-foreground">Recarregue sua conta já</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-1 w-16 bg-primary/20 rounded-full overflow-hidden">
            <div className="h-full w-1/2 bg-primary rounded-full" />
          </div>
          <ArrowRight className="h-5 w-5 text-primary group-hover:translate-x-1 transition-transform" />
        </div>
      </button>
    </div>
  );
};

export default DepositCTA;
