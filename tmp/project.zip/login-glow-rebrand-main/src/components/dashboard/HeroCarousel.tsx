import { useState, useEffect } from "react";
import OptimizedImage from "@/components/OptimizedImage";

// Dynamic imports for images to enable code splitting
const heroImagePaths = [
  () => import("@/assets/worker-hero.jpg"),
  () => import("@/assets/diamonds-hero.jpg"),
  () => import("@/assets/diamonds-bg.jpg"),
];

interface HeroCarouselProps {
  onFirstImageLoaded?: () => void;
}

const HeroCarousel = ({ onFirstImageLoaded }: HeroCarouselProps) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [heroImages, setHeroImages] = useState<string[]>([]);
  const [firstImageLoaded, setFirstImageLoaded] = useState(false);

  // Load images dynamically
  useEffect(() => {
    const loadImages = async () => {
      const images = await Promise.all(
        heroImagePaths.map(async (importFn) => {
          const module = await importFn();
          return module.default;
        })
      );
      setHeroImages(images);
    };
    loadImages();
  }, []);

  // Auto-slide
  useEffect(() => {
    if (heroImages.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [heroImages.length]);

  const handleFirstLoad = () => {
    if (!firstImageLoaded) {
      setFirstImageLoaded(true);
      onFirstImageLoaded?.();
    }
  };

  if (heroImages.length === 0) {
    return (
      <div className="relative w-full h-36 sm:h-44 md:aspect-[3/1] md:h-auto lg:aspect-[4/1] bg-primary/10 animate-pulse" />
    );
  }

  return (
    <div className="relative w-full bg-primary/10 overflow-hidden">
      <div className="relative w-full h-36 sm:h-44 md:aspect-[3/1] md:h-auto lg:aspect-[4/1]">
        {heroImages.map((img, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              currentSlide === index ? "opacity-100" : "opacity-0"
            }`}
          >
            <OptimizedImage
              src={img}
              alt={`Slide ${index + 1}`}
              className="w-full h-full"
              priority={index === 0}
              onLoad={index === 0 ? handleFirstLoad : undefined}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 via-transparent to-transparent" />
          </div>
        ))}
        {/* Slide Indicators */}
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2 z-10">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`h-2 rounded-full transition-all shadow-sm ${
                currentSlide === index ? "bg-primary w-6" : "bg-white/70 w-2"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HeroCarousel;
