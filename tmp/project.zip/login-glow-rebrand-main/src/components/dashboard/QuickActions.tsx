import { useNavigate } from "react-router-dom";
import { Calendar, CreditCard, Banknote, LayoutGrid, Users, HelpCircle } from "lucide-react";

const quickActions = [
  { icon: Calendar, label: "Check-in", route: "/daily-checkin" },
  { icon: CreditCard, label: "Depósito", route: "/deposit" },
  { icon: Banknote, label: "Saque", route: "/withdraw" },
  { icon: LayoutGrid, label: "Planos", route: "/plans" },
  { icon: Users, label: "Indicação", route: "/referral" },
  { icon: HelpCircle, label: "Suporte", route: "/support" },
];

const QuickActions = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-card rounded-xl p-4 shadow-sm">
      <h2 className="text-lg font-bold text-foreground mb-4">Ações Rápidas</h2>
      <div className="grid grid-cols-3 gap-3 md:gap-4">
        {quickActions.map((action, index) => (
          <button
            key={index}
            onClick={() => navigate(action.route)}
            className="flex flex-col items-center justify-center p-4 md:p-6 bg-background rounded-lg border border-border hover:border-primary hover:shadow-md transition-all group"
          >
            <action.icon className="h-6 w-6 md:h-7 md:w-7 text-primary mb-2 group-hover:scale-110 transition-transform" />
            <span className="text-xs md:text-sm text-muted-foreground group-hover:text-foreground">{action.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;
