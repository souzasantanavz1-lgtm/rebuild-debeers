import { User, TrendingUp } from "lucide-react";

const recentGains = [
  { name: "João S.****", activity: "Cofre de Diamantes", amount: "88.00", time: "10 min atrás" },
  { name: "Diego F.*******", activity: "Diamante Lapidado", amount: "20.00", time: "15 min atrás" },
  { name: "Mariana D.***", activity: "Coleção De Beers", amount: "180.00", time: "1 min atrás" },
  { name: "Vinicius B.*****", activity: "Tesouro De Beers", amount: "220.00", time: "7 min atrás" },
  { name: "Isabela A.*****", activity: "Diamante Bruto", amount: "10.00", time: "10 min atrás" },
  { name: "Carlos M.***", activity: "Mina de Diamantes", amount: "275.00", time: "3 min atrás" },
  { name: "Ana P.****", activity: "Lapidação Premium", amount: "400.00", time: "5 min atrás" },
];

const RecentGains = () => {
  return (
    <div className="bg-card rounded-xl p-4 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-bold text-foreground">Ganhos Recentes</h2>
      </div>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
        {recentGains.map((gain, index) => (
          <div
            key={index}
            className="flex-shrink-0 w-40 md:w-48 bg-background rounded-lg p-3 border border-border"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                <User className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{gain.name}</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground truncate mb-1">{gain.activity}</p>
            <div className="flex items-center justify-between">
              <span className="text-primary font-bold">+R$ {gain.amount}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">{gain.time}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentGains;
