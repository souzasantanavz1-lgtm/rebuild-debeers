import { useState, useEffect } from "react";
import { Zap, Wallet, Star, MessageCircle, Rocket, AlertTriangle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import deBeersLogo from "@/assets/de-beers-logo.svg";

interface WelcomeCardProps {
  onClose: () => void;
}

const WelcomeCard = ({ onClose }: WelcomeCardProps) => {
  const [isClosing, setIsClosing] = useState(false);

  // Auto-dismiss after 10 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      handleClose();
    }, 10000);
    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      onClose();
    }, 300);
  };

  return (
    <Card className={`w-full max-w-md shadow-2xl border-border overflow-hidden relative my-auto transition-all duration-300 pointer-events-auto ${isClosing ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
      {/* Close Button */}
      <button 
        type="button"
        onClick={handleClose}
        className="absolute top-2 right-2 z-20 bg-destructive text-destructive-foreground rounded-full p-1.5 hover:bg-destructive/90 transition-colors cursor-pointer"
        aria-label="Fechar"
      >
        <X className="h-5 w-5" />
      </button>

      {/* Card Header with Logo */}
      <div className="bg-primary py-4 flex justify-center">
        <div className="bg-card rounded-lg p-3 shadow-md">
          <img src={deBeersLogo} alt="De Beers" className="h-8 w-auto" />
        </div>
      </div>

      <CardContent className="p-6 space-y-4">
        {/* Title */}
        <h1 className="text-xl font-bold text-center text-primary">
          Lucro Diário Automático 💎
        </h1>

        {/* Deposit and Withdraw Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-secondary/50 rounded-lg p-4 border border-primary/20">
            <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
              <Zap className="h-4 w-4 text-primary" />
              <span>Depósito</span>
            </div>
            <p className="text-primary font-bold text-lg">R$ 20.00</p>
          </div>
          <div className="bg-secondary/50 rounded-lg p-4 border border-primary/20">
            <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
              <Wallet className="h-4 w-4 text-primary" />
              <span>Saque</span>
            </div>
            <p className="text-primary font-bold text-lg">R$ 20 (12%)</p>
          </div>
        </div>

        {/* Referral Program */}
        <div className="bg-secondary/30 rounded-lg p-4 border border-border">
          <div className="flex items-center gap-2 mb-3">
            <Star className="h-4 w-4 text-primary" />
            <span className="font-semibold text-foreground">Programa de Indicação</span>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground mb-2">1ª Compra</p>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span>N1 🥇:</span>
                  <span className="text-primary font-medium">15%</span>
                </div>
                <div className="flex justify-between">
                  <span>N2 🥈:</span>
                  <span className="text-primary font-medium">2%</span>
                </div>
                <div className="flex justify-between">
                  <span>N3 🥉:</span>
                  <span className="text-primary font-medium">1%</span>
                </div>
              </div>
            </div>
            <div>
              <p className="text-muted-foreground mb-2">Demais</p>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span>N1 🥇:</span>
                  <span className="text-primary font-medium">8%</span>
                </div>
                <div className="flex justify-between">
                  <span>N2 🥈:</span>
                  <span className="text-primary font-medium">1%</span>
                </div>
                <div className="flex justify-between">
                  <span>N3 🥉:</span>
                  <span className="text-primary font-medium">1%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Warning */}
        <div className="bg-muted rounded-lg p-3 flex items-center justify-center gap-2 text-muted-foreground text-sm">
          <AlertTriangle className="h-4 w-4" />
          <span>Só saca com plano ativo</span>
        </div>

        {/* WhatsApp Buttons */}
        <div className="space-y-3">
          <Button className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-medium">
            <MessageCircle className="mr-2 h-5 w-5" />
            Grupo WhatsApp #2
          </Button>
          <Button className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-medium">
            <MessageCircle className="mr-2 h-5 w-5" />
            Grupo WhatsApp #1
          </Button>
        </div>

        {/* Start Button */}
        <Button variant="outline" className="w-full h-12 border-2 border-primary text-primary font-medium hover:bg-primary hover:text-primary-foreground">
          Começar Agora <Rocket className="ml-2 h-5 w-5" />
        </Button>
      </CardContent>
    </Card>
  );
};

export default WelcomeCard;
