import { useNavigate, useLocation } from "react-router-dom";
import { Home, CreditCard, Banknote, LayoutGrid, User } from "lucide-react";

interface NavItem {
  icon: typeof Home;
  label: string;
  route: string;
}

const navItems: NavItem[] = [
  { icon: Home, label: "Início", route: "/dashboard" },
  { icon: CreditCard, label: "Depositar", route: "/deposit" },
  { icon: Banknote, label: "Sacar", route: "/withdraw" },
  { icon: LayoutGrid, label: "Planos", route: "/plans" },
  { icon: User, label: "Perfil", route: "/profile" },
];

const BottomNavigation = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavigation = (route: string) => {
    if (location.pathname !== route) {
      navigate(route);
    }
  };

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 py-3 z-[100]"
      style={{ pointerEvents: 'auto' }}
    >
      <div className="flex justify-around items-center max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.route;
          const Icon = item.icon;
          
          return (
            <button
              type="button"
              key={item.route}
              onClick={() => handleNavigation(item.route)}
              className={`flex flex-col items-center transition-colors cursor-pointer p-2 ${
                isActive ? "text-primary" : "text-muted-foreground hover:text-primary"
              }`}
            >
              <Icon className="h-6 w-6" />
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNavigation;
