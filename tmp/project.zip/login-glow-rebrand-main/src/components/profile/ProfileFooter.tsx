import { Diamond } from "lucide-react";

const ProfileFooter = () => {
  return (
    <div className="mt-6 text-center">
      <div className="flex items-center justify-center gap-2 text-muted-foreground">
        <Diamond className="h-4 w-4" />
        <span className="text-sm">De Beers Investimentos</span>
        <Diamond className="h-4 w-4" />
      </div>
      <p className="text-xs text-muted-foreground/60 mt-1">Versão 1.0.0</p>
    </div>
  );
};

export default ProfileFooter;
