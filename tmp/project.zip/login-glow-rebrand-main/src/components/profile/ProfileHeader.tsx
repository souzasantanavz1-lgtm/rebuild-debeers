import { User, CreditCard, Banknote } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface ProfileHeaderProps {
  investmentBalance: number;
}

const ProfileHeader = ({ investmentBalance }: ProfileHeaderProps) => {
  const navigate = useNavigate();

  return (
    <header className="bg-gradient-to-b from-primary to-primary/80 pt-8 pb-6 px-4">
      <div className="bg-primary/40 backdrop-blur-sm rounded-2xl p-6 max-w-md mx-auto border border-primary-foreground/10">
        {/* Avatar */}
        <div className="flex justify-center mb-4">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-amber-400 to-amber-500 flex items-center justify-center border-4 border-amber-300 shadow-lg">
              <User className="h-12 w-12 text-primary" />
            </div>
            {/* VIP Badge */}
            <div className="absolute -bottom-1 -right-1 bg-amber-400 text-primary text-xs font-bold px-2 py-0.5 rounded-full border-2 border-amber-300 shadow">
              VIP
            </div>
          </div>
        </div>

        {/* Balance Display */}
        <div className="bg-primary/30 rounded-xl py-3 px-4 mb-4 text-center border border-primary-foreground/10">
          <span className="text-primary-foreground/70 text-sm">saldo atual </span>
          <span className="text-primary-foreground font-bold text-xl">R$ {investmentBalance.toFixed(2)}</span>
        </div>

        {/* Deposit and Withdraw Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => navigate("/deposit")}
            className="bg-cyan-500 hover:bg-cyan-600 text-white rounded-xl py-4 flex flex-col items-center gap-2 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] shadow-md"
          >
            <CreditCard className="h-8 w-8" />
            <span className="font-medium">depósito</span>
          </button>
          <button
            onClick={() => navigate("/withdraw")}
            className="bg-gradient-to-r from-pink-500 to-pink-400 hover:from-pink-600 hover:to-pink-500 text-white rounded-xl py-4 flex flex-col items-center gap-2 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] shadow-md"
          >
            <Banknote className="h-8 w-8" />
            <span className="font-medium">Retirada</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default ProfileHeader;
