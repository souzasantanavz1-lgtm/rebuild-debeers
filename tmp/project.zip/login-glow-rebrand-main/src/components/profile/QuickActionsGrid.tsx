import { LucideIcon } from "lucide-react";

interface QuickAction {
  icon: LucideIcon;
  label: string;
  color: string;
  action: () => void;
}

interface QuickActionsGridProps {
  actions: QuickAction[];
}

const QuickActionsGrid = ({ actions }: QuickActionsGridProps) => {
  return (
    <div className="bg-card rounded-2xl p-6 shadow-sm border border-border shadow-md">
      <h2 className="text-lg font-bold text-foreground mb-4">Ações Rápidas</h2>
      
      <div className="grid grid-cols-4 gap-4">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={index}
              onClick={action.action}
              className="flex flex-col items-center gap-2 group"
            >
              <div className={`${action.color} w-14 h-14 rounded-xl flex items-center justify-center shadow-md transition-all duration-200 group-hover:scale-110 group-active:scale-95`}>
                <Icon className="h-6 w-6 text-white" />
              </div>
              <span className="text-xs text-muted-foreground text-center leading-tight">
                {action.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default QuickActionsGrid;
