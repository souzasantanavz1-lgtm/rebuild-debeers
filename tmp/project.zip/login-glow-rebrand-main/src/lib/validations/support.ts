import { z } from "zod";

// Schema for support ticket validation
// Prevents XSS by restricting allowed characters and enforcing length limits
export const supportTicketSchema = z.object({
  subject: z
    .string()
    .min(5, "Assunto deve ter no mínimo 5 caracteres")
    .max(200, "Assunto deve ter no máximo 200 caracteres")
    .regex(
      /^[a-zA-Z0-9\s\u00c0-\u017f.,!?'":;()\-@#$%&*+=]+$/,
      "Assunto contém caracteres não permitidos"
    ),
  message: z
    .string()
    .min(10, "Mensagem deve ter no mínimo 10 caracteres")
    .max(2000, "Mensagem deve ter no máximo 2000 caracteres"),
});

export type SupportTicketInput = z.infer<typeof supportTicketSchema>;

// Sanitize text by removing potential script injections
// This is a basic client-side sanitization - server-side should also sanitize
export function sanitizeText(text: string): string {
  return text
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<[^>]*>/g, '')
    .replace(/javascript:/gi, '')
    .replace(/on\w+=/gi, '')
    .trim();
}
