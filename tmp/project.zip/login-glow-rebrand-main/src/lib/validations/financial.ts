import { z } from "zod";

// CPF validation helper
const validateCPF = (cpf: string): boolean => {
  const cleaned = cpf.replace(/\D/g, "");
  
  if (cleaned.length !== 11) return false;
  
  // Check for known invalid patterns
  if (/^(\d)\1{10}$/.test(cleaned)) return false;
  
  // Validate first check digit
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cleaned.charAt(i)) * (10 - i);
  }
  let remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cleaned.charAt(9))) return false;
  
  // Validate second check digit
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cleaned.charAt(i)) * (11 - i);
  }
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cleaned.charAt(10))) return false;
  
  return true;
};

// Deposit validation schema
export const depositSchema = z.object({
  amount: z
    .number({ required_error: "Valor é obrigatório" })
    .min(30, "Valor mínimo é R$ 30,00")
    .max(100000, "Valor máximo é R$ 100.000,00"),
  cpf: z
    .string()
    .min(1, "CPF é obrigatório")
    .regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/, "CPF deve estar no formato 000.000.000-00")
    .refine(validateCPF, "CPF inválido"),
});

// Withdraw validation schema
export const withdrawSchema = z.object({
  amount: z
    .number({ required_error: "Valor é obrigatório" })
    .min(30, "Valor mínimo é R$ 30,00")
    .max(100000, "Valor máximo é R$ 100.000,00"),
  cpf: z
    .string()
    .min(1, "CPF é obrigatório")
    .regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/, "CPF deve estar no formato 000.000.000-00")
    .refine(validateCPF, "CPF inválido"),
  pixKeyType: z.enum(["cpf", "email", "phone", "random"], {
    required_error: "Tipo de chave PIX é obrigatório",
  }),
  pixKey: z
    .string()
    .min(1, "Chave PIX é obrigatória")
    .max(100, "Chave PIX muito longa"),
});

// PIX key type-specific validation
export const validatePixKey = (type: string, key: string): string | null => {
  switch (type) {
    case "cpf":
      if (!/^\d{3}\.\d{3}\.\d{3}-\d{2}$/.test(key)) {
        return "CPF deve estar no formato 000.000.000-00";
      }
      if (!validateCPF(key)) {
        return "CPF inválido";
      }
      break;
    case "email":
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(key)) {
        return "E-mail inválido";
      }
      break;
    case "phone":
      if (!/^\(\d{2}\)\s?\d{4,5}-\d{4}$/.test(key)) {
        return "Telefone deve estar no formato (00) 00000-0000";
      }
      break;
    case "random":
      if (key.length < 10) {
        return "Chave aleatória inválida";
      }
      break;
  }
  return null;
};

// Types inferred from schemas
export type DepositFormData = z.infer<typeof depositSchema>;
export type WithdrawFormData = z.infer<typeof withdrawSchema>;
