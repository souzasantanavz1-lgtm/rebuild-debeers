
# Plano: Validacao Completa para Login e Cadastro - De Beers

## Resumo

Implementar validacao robusta no frontend com Zod + React Hook Form, e configurar Supabase/Lovable Cloud para validacao e autenticacao no backend com hash bcrypt nativo.

---

## Arquitetura da Solucao

```text
+-------------------+       +------------------------+       +------------------+
|    Frontend       |       |     Supabase Auth      |       |   Edge Function  |
|  (React + Zod)    | ----> |   (bcrypt nativo)      | <---> |  (validacao)     |
+-------------------+       +------------------------+       +------------------+
        |                            |
        v                            v
  Validacao local              Hash automatico
  Feedback imediato            Usuarios unicos
```

---

## Etapas de Implementacao

### 1. Configurar Lovable Cloud/Supabase

Antes de implementar o codigo, sera necessario conectar o projeto ao Supabase ou Lovable Cloud para habilitar:
- Autenticacao nativa com hash bcrypt automatico
- Validacao de e-mail unico no servidor
- Armazenamento seguro de usuarios

### 2. Criar Schemas de Validacao com Zod

Criar arquivo `src/lib/validations/auth.ts` com regras de validacao:

**E-mail:**
- Obrigatorio
- Formato valido (regex)
- Minimo 6 caracteres
- Maximo 255 caracteres

**Senha:**
- Obrigatoria
- Minimo 8 caracteres
- Deve conter letras E numeros

**Confirmacao de Senha (cadastro):**
- Obrigatoria
- Deve ser igual a senha

**Nome Completo (cadastro):**
- Obrigatorio
- Minimo 2 caracteres
- Maximo 100 caracteres

### 3. Refatorar Pagina de Login (`src/pages/Index.tsx`)

Alteracoes:
- Integrar React Hook Form com resolver Zod
- Adicionar mensagens de erro inline abaixo de cada campo
- Desabilitar botao durante submissao
- Validar formato antes de enviar ao servidor
- Exibir toast com erro generico se credenciais invalidas

### 4. Refatorar Pagina de Cadastro (`src/pages/Register.tsx`)

Alteracoes:
- Adicionar campo "Confirmar Senha"
- Integrar React Hook Form com resolver Zod
- Adicionar mensagens de erro inline
- Validar todos os campos antes do submit
- Conectar com Supabase Auth para criar usuario

### 5. Criar Edge Function de Validacao (backend)

Criar `supabase/functions/validate-auth/index.ts` para:
- Validacao no servidor como camada adicional de seguranca
- Verificar e-mail unico no cadastro
- Retornar mensagens de erro claras em portugues

---

## Detalhes Tecnicos

### Schema de Login (Zod)

```typescript
const loginSchema = z.object({
  email: z
    .string()
    .min(1, "E-mail e obrigatorio")
    .min(6, "E-mail deve ter no minimo 6 caracteres")
    .max(255, "E-mail deve ter no maximo 255 caracteres")
    .email("Formato de e-mail invalido"),
  password: z
    .string()
    .min(1, "Senha e obrigatoria")
    .min(8, "Senha deve ter no minimo 8 caracteres"),
});
```

### Schema de Cadastro (Zod)

```typescript
const registerSchema = z.object({
  name: z
    .string()
    .min(1, "Nome e obrigatorio")
    .min(2, "Nome deve ter no minimo 2 caracteres")
    .max(100, "Nome deve ter no maximo 100 caracteres"),
  email: z
    .string()
    .min(1, "E-mail e obrigatorio")
    .min(6, "E-mail deve ter no minimo 6 caracteres")
    .max(255, "E-mail deve ter no maximo 255 caracteres")
    .email("Formato de e-mail invalido"),
  phone: z.string().optional(),
  referralCode: z.string().optional(),
  password: z
    .string()
    .min(1, "Senha e obrigatoria")
    .min(8, "Senha deve ter no minimo 8 caracteres")
    .regex(/[a-zA-Z]/, "Senha deve conter letras")
    .regex(/[0-9]/, "Senha deve conter numeros"),
  passwordConfirmation: z.string().min(1, "Confirmacao e obrigatoria"),
}).refine((data) => data.password === data.passwordConfirmation, {
  message: "As senhas nao conferem",
  path: ["passwordConfirmation"],
});
```

### Componentes de Erro

Cada campo exibira mensagem de erro em vermelho logo abaixo do input:

```text
+------------------------------------------+
|  E-mail *                                |
|  +------------------------------------+  |
|  | usuario@email                      |  |
|  +------------------------------------+  |
|  [!] E-mail deve ter no minimo 6 chars   |
+------------------------------------------+
```

### Integracao com Supabase Auth

O Supabase Auth ja fornece:
- Hash bcrypt automatico para senhas
- Verificacao de e-mail unico
- Tokens JWT seguros
- Confirmacao por e-mail (opcional)

---

## Arquivos a Criar/Modificar

| Arquivo | Acao | Descricao |
|---------|------|-----------|
| `src/lib/validations/auth.ts` | Criar | Schemas Zod para login e cadastro |
| `src/pages/Index.tsx` | Modificar | Integrar validacao no login |
| `src/pages/Register.tsx` | Modificar | Adicionar confirmacao de senha e validacao |
| `supabase/functions/validate-auth/index.ts` | Criar | Validacao server-side |
| `supabase/config.toml` | Modificar | Configurar edge function |

---

## Proximos Passos Apos Aprovacao

1. **Conectar Lovable Cloud ou Supabase** - Necessario para autenticacao real
2. Implementar schemas de validacao
3. Refatorar formularios com React Hook Form
4. Criar edge function para validacao backend
5. Testar fluxo completo de login e cadastro

---

## Mensagens de Erro (Portugues)

| Campo | Validacao | Mensagem |
|-------|-----------|----------|
| E-mail | Vazio | "E-mail e obrigatorio" |
| E-mail | Formato | "Formato de e-mail invalido" |
| E-mail | Min 6 | "E-mail deve ter no minimo 6 caracteres" |
| E-mail | Max 255 | "E-mail deve ter no maximo 255 caracteres" |
| Senha | Vazia | "Senha e obrigatoria" |
| Senha | Min 8 | "Senha deve ter no minimo 8 caracteres" |
| Senha | Letras | "Senha deve conter letras" |
| Senha | Numeros | "Senha deve conter numeros" |
| Confirmacao | Diferente | "As senhas nao conferem" |
| Login falho | Credenciais | "E-mail ou senha invalidos" |
| Cadastro | E-mail em uso | "Este e-mail ja esta em uso" |
